---
title: State Wise Sales (Domestic)
---
<h1>State Wise Sales Report</h1>
<div class="grid grid-cols-2"> 
  <div class="card grid-rowspan-2" id="state_order_map">
    <div class="flourish-embed flourish-map" data-src="visualisation/22446165"><script src="https://public.flourish.studio/resources/embed.js"></script><noscript><img src="https://public.flourish.studio/visualisation/22446165/thumbnail" width="100%" alt="map visualization" /></noscript></div>
  </div>
  <div class="card" id="state_order_bar_chart" >
    <div class="flourish-embed flourish-chart" data-src="visualisation/22458211"><script src="https://public.flourish.studio/resources/embed.js"></script><noscript><img src="https://public.flourish.studio/visualisation/22458211/thumbnail" width="100%" alt="chart visualization" /></noscript></div>
    <h2> Top 5 by sales amount & category Distribution</h2>
  </div>
  <div class="card" >
    <div class="flourish-embed flourish-chart" data-src="visualisation/22373061"><script src="https://public.flourish.studio/resources/embed.js"></script><noscript><img src="https://public.flourish.studio/visualisation/22373061/thumbnail" width="100%" alt="chart visualization" /></noscript></div>
    <h2>Day wise Amzaon dataset</h2>
  </div>

</div>