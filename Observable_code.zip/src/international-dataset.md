---
title: International Sales Report
---
# International Sales Data

<div class="grid grid-cols-4">
  <div class="card">
    <h3>Total Items Sold</h3>
    <h1>24,700</h1>
  </div>
  <div class="card">
    <h3>Avg Order Sales</h3>
    <h1>835.05</h1>
  </div>
  <div class="card">
    <h3>Max Sales Date</h3>
    <h1>14/09/2021</h1>
  </div>
  <div class="card">
    <h3>Min Sales Day</h3>
    <h1>20/05/2021</h1>
    </div>
</div>

<div class ="card">
    <div class="flourish-embed flourish-scatter" data-src="visualisation/22467089"><script src="https://public.flourish.studio/resources/embed.js"></script><noscript><img src="https://public.flourish.studio/visualisation/22467089/thumbnail" width="100%" alt="scatter visualization" /></noscript></div>
</div>

<div class="grid grid-cols-2">
  
  <div class="card">
    <div class="flourish-embed flourish-chart" data-src="visualisation/22446061"><script src="https://public.flourish.studio/resources/embed.js"></script><noscript><img src="https://public.flourish.studio/visualisation/22446061/thumbnail" width="100%" alt="chart visualization" /></noscript></div>
  </div>

  <div class="card">
    <div class="flourish-embed flourish-gauge" data-src="visualisation/22371486"><script src="https://public.flourish.studio/resources/embed.js"></script><noscript><img src="https://public.flourish.studio/visualisation/22371486/thumbnail" width="100%" alt="gauge visualization" /></noscript></div>
  </div>
</div>



</div>
