---
title: Domestic Vs International Sales
---

<h1>Domestic Vs International Sales</h1>
<div class= "grid grid-cols-2">
  <div class="card">
    <div class="flourish-embed flourish-gauge" data-src="visualisation/22372760"><script src="https://public.flourish.studio/resources/embed.js"></script><noscript><img src="https://public.flourish.studio/visualisation/22372760/thumbnail" width="100%" alt="gauge visualization" /></noscript></div>
  </div>
  <div class="card">
    <div class="flourish-embed flourish-gauge" data-src="visualisation/22371486"><script src="https://public.flourish.studio/resources/embed.js"></script><noscript><img src="https://public.flourish.studio/visualisation/22371486/thumbnail" width="100%" alt="gauge visualization" /></noscript></div>
  </div>
</div>


<div class="grid grid-cols-2">
  <div class ="card">
    <div class="flourish-embed flourish-chart" data-src="visualisation/22446003"><script src="https://public.flourish.studio/resources/embed.js"></script><noscript><img src="https://public.flourish.studio/visualisation/22446003/thumbnail" width="100%" alt="chart visualization" /></noscript></div>
  </div>
  <div class="card">
    <div class="flourish-embed flourish-chart" data-src="visualisation/22487119"><script src="https://public.flourish.studio/resources/embed.js"></script><noscript><img src="https://public.flourish.studio/visualisation/22487119/thumbnail" width="100%" alt="chart visualization" /></noscript></div>
  </div>
</div>

<div class="grid grid-cols-2">
  <div class="card">
    <div class="flourish-embed flourish-chart" data-src="visualisation/22467574"><script src="https://public.flourish.studio/resources/embed.js"></script><noscript><img src="https://public.flourish.studio/visualisation/22467574/thumbnail" width="100%" alt="chart visualization" /></noscript></div>
  </div>
  <div class="card">
    <div class="flourish-embed flourish-chart" data-src="visualisation/22467481"><script src="https://public.flourish.studio/resources/embed.js"></script><noscript><img src="https://public.flourish.studio/visualisation/22467481/thumbnail" width="100%" alt="chart visualization" /></noscript></div>
  </div>
</div>