---
title: Product Sales WRT Time
---
<h1> Product Sales WRT to Time</h1>
<div class="card" >
  <div class="flourish-embed flourish-bar-chart-race" data-src="visualisation/22376883"><script src="https://public.flourish.studio/resources/embed.js"></script><noscript><img src="https://public.flourish.studio/visualisation/22376883/thumbnail" width="100%" alt="bar-chart-race visualization" /></noscript></div>
</div> 